RAIK 378H - Project 2 - Stage 1
=============================

Sawyer Jager
Rees Klintworth
Derek Nordgren
Brad Steiner

4/22/2013

Files included:
* Apriori/src/
	* Apriori.java : application file to run application
	* AprioriCalculator : Java implementation of Apriori algorithm
* Report1.pdf : analytical portion of assignment
* Apriori/project_2_output.txt : Apriori algorithm output for generated input files
* C Code/generate_input.c : C file used to generate input files from provided data for use in Apriori algorithm
* Provided code includes C basket files and other provided code for the assignment

Notes:
* We have omitted the provided .dat files from our handin
* Code should be runnable "out of the box" - please contact us if you have any issues
